#ifndef MAIN_H
#define MAIN_H

#include "libs.h"

#include "Heroes/Hero.h"
#include "Heroes/Dog.h"
#include "Heroes/Cat.h"
#include "Heroes/Rat.h"
#include "Barriers/Barrier.h"
#include "Barriers/Human.h"
#include "Barriers/Guard.h"
#include "Barriers/MichalJakson.h"

#endif // LIBS_H

