#ifndef DOG_H
#define DOG_H

#include "Hero.h"
#include "libs.h"

class Dog: public Hero{
    public:
        Dog();
        void yelName();
};

#endif

