#ifndef CAT_H
#define CAT_H

#include "Hero.h"
#include "libs.h"

class Cat: public Hero{
    public:
        Cat();
        void yelName();
};

#endif
