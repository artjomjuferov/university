#ifndef RAT_H
#define RAT_H

#include "Hero.h"
#include "libs.h"

class Rat: public Hero{
    public:
        Rat();
        void yelName();
};

#endif
