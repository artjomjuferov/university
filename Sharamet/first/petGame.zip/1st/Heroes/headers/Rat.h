#ifndef HERO
#define HERO
#include "Hero.h"
#endif
#include <iostream>

class Rat: public Hero{
	public:
		Rat();
		void yelName();
};