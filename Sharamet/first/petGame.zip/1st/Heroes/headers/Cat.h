#ifndef HERO
#define HERO
#include "Hero.h"
#endif
#include <iostream>

class Cat: public Hero{
	public:
		Cat();
		void yelName();
};