#ifndef HERO
#define HERO
#include "Hero.h"
#endif
#include <iostream>

class Dog: public Hero{
	public:
		Dog();
		void yelName();
};