#include "dialoggame.h"
#include "ui_dialoggame.h"

DialogGame::DialogGame(Hero* hero, QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DialogGame)
{
    ui->setupUi(this);
    ui->pushButton_2->setHidden(true);

    mainHero = hero;

    qScene = new QGraphicsScene();

    int tmp = rand() %3;
    Barrier *bar;
    if (tmp == 0){
        bar = new Human;
    } else if(tmp == 1){
        bar = new Guard;
    } else {
        bar = new MichalJakson;
    }


    QString text = "I'm ";
                text += bar->name;

    text += bar->doAction(mainHero, qScene);

    ui->textBrowser->setText(text);
    ui->textBrowser_3->setText(QString::number(this->steps));
    ui->textBrowser_2->setText(QString::number(mainHero->getHp()));

    ui->graphicsView->setScene(qScene);
    ui->graphicsView->fitInView(qScene->sceneRect(), Qt::KeepAspectRatio);

}

DialogGame::~DialogGame()
{
    delete ui;
}


void DialogGame::on_pushButton_2_clicked()
{
    this->hide();
}


void DialogGame::on_pushButton_clicked()
{
    int tmp = rand() %3;
    Barrier *bar;
    if (tmp == 0){
        bar = new Human;
    } else if(tmp == 1){
        bar = new Guard;
    } else {
        bar = new MichalJakson;
    }

    QString text = "I'm ";
                text += bar->name;

    text += bar->doAction(mainHero, qScene);

    ui->textBrowser->setText(text);
    this->steps--;
    ui->textBrowser_3->setText(QString::number(this->steps));
    ui->textBrowser_2->setText(QString::number(mainHero->getHp()));


    ui->graphicsView->setScene(qScene);
    ui->graphicsView->fitInView(qScene->sceneRect(), Qt::KeepAspectRatio);

    if (!mainHero->isAlive()){
        ui->textBrowser->setText("You're DEAD");
        ui->pushButton->setHidden(true);
        ui->pushButton_2->setHidden(false);


        qScene->clear();
        qScene->addPixmap(QPixmap(":img/lose"));
        ui->graphicsView->setScene(qScene);
        ui->graphicsView->fitInView(qScene->sceneRect(), Qt::KeepAspectRatio);

        return;
    }

    if (this->steps == 0){
        ui->textBrowser->setText("You're winner");
        ui->pushButton->setHidden(true);
        ui->pushButton_2->setHidden(false);

        qScene->clear();
        qScene->addPixmap(QPixmap(":img/win"));
        ui->graphicsView->setScene(qScene);
        ui->graphicsView->fitInView(qScene->sceneRect(), Qt::KeepAspectRatio);
        return;
    }

}
