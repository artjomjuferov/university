#ifndef LIBS_H
#define LIBS_H
#include <stdlib.h>
#include "QString"

#endif // LIBS_H
