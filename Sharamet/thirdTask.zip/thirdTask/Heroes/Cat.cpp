#include "Cat.h"

Cat::Cat(){
	hp = 100;
	speed = 70;
	luck = 200;
    img = ":/img/cat";
}

void Cat::yelName(){
}
