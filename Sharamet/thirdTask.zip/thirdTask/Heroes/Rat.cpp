#include "Rat.h"


Rat::Rat(){
	hp = 200;
	speed = 20;
	luck = 200;
    img = ":/img/rat";
}

void Rat::yelName(){
}
