#include "Dog.h"

Dog::Dog(){
	hp = 200;
	speed = 50;
	luck = 100;
    img = ":/img/dog";
}

void Dog::yelName(){
}
